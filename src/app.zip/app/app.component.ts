import { Component, PLATFORM_ID, inject } from '@angular/core';
import {
  Router,
  NavigationEnd,
  NavigationStart,
  RouterOutlet,
  RouterModule,
} from '@angular/router';
import { CommonModule, isPlatformBrowser, DOCUMENT } from '@angular/common';
import { filter } from 'rxjs/operators';
import {
  trigger,
  transition,
  style,
  animate,
  query,
  group,
} from '@angular/animations';

import { NavbarComponent } from './core/navbar.component';
import { CocktailBubblesComponent } from './assets/design-system/cocktail-bubbles/cocktail-bubbles.component';
import { FooterComponent } from './core/footer.component';
import { ViewportService } from './services/viewport.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    NavbarComponent,
    RouterOutlet,
    RouterModule,
    CocktailBubblesComponent,
    FooterComponent,
  ],
  animations: [
    trigger('pageTransition', [
      // ... (transizione 'noanim')

      transition(
        '* <=> *',
        [
          // 1. Setup (OK)
          style({ position: 'relative' }),
          query(':leave', [style({ zIndex: 1, pointerEvents: 'none' })], {
            optional: true,
          }),
          // 2. Clear Layering (MODIFICA: :leave SOPRA a :enter)
          // La pagina che esce (leave) sta sopra (zIndex: 1)
          query(':leave', [style({ zIndex: 1, pointerEvents: 'none' })], {
            optional: true,
          }),
          // La pagina che entra (enter) sta sotto (zIndex: 0)
          // Passo 2: Clear Layering - Enter
          query(':enter', [style({ zIndex: 0 })], { optional: true }),

          // 3. Stato Iniziale di :enter (OK)
          // ...

          // 4. Esecuzione in PARALLELO (group) - Aggiungi un piccolo delay a :enter
          group([
            // Leave: va via in dissolvenza (OK)
            query(
              ':leave',
              [
                animate(
                  '{{leaveDuration}}',
                  style({
                    opacity: 0,
                    transform: 'translateY({{leaveY}})',
                  })
                ),
              ],
              { optional: true }
            ),

            // Enter: Entra con slide/fade morbido (AGGIUNGI DELAY per l'effetto soave)
            query(
              ':enter',
              [
                // **Aggiungi un delay di 50ms** per consentire a :leave di iniziare a sbiadire.
                animate(
                  '50ms {{enterDuration}}', // Delay di 50ms + Durata di animazione
                  style({
                    opacity: 1,
                    transform: 'translateY(0)',
                  })
                ),
              ],
              { optional: true }
            ),
          ]),
        ],
        {
          params: {
            // Curva moderna "overshoot" o "snappy":
            // L'uscita è rapida e lineare, l'entrata è soave e con effetto elastico
            enterDuration: '300ms cubic-bezier(0.17, 0.88, 0.32, 1.27)', // Overshoot/Elasticità
            leaveDuration: '200ms ease-out',
            enterY: '10px', // Entra da sotto
            leaveY: '-10px', // Esce salendo
          },
        }
      ),
    ]),
  ],

  template: `
    <app-navbar></app-navbar>
    <main
      class="app-main"
      [@pageTransition]="{
        value: getRouteAnimationData(routerOutlet),
        params: animParams
      }"
    >
      <router-outlet #routerOutlet="outlet"></router-outlet>
    </main>
    @defer (on idle) {
    <app-footer></app-footer>
    } @placeholder {
    <footer class="app-footer-placeholder" aria-hidden="true"></footer>
    } @if (showAmbient) { @defer (on idle) {
    <app-cocktail-bubbles></app-cocktail-bubbles>
    } @placeholder {
    <div class="cocktail-bubbles-placeholder" aria-hidden="true"></div>
    } }
  `,
  styles: [
    `
      @use './assets/style/main.scss' as *;

      .app-footer-placeholder {
        display: block;
        min-height: 120px;
        width: 100%;
      }

      .cocktail-bubbles-placeholder {
        position: fixed;
        inset: auto 0 0 0;
        height: 0;
      }
    `,
  ],
})
export class AppComponent {
  private router = inject(Router);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly viewportService = inject(ViewportService);
  private readonly isBrowser = isPlatformBrowser(this.platformId);
  private readonly document = inject(DOCUMENT);

  // flag interno per saltare le animazioni nella prossima navigazione (filtri, ecc.)
  private skipMotionNext = false;

  // 👉 params “mobile-safe”
  protected readonly isTouch =
    this.isBrowser &&
    (navigator.maxTouchPoints > 0 ||
      /Android|iP(ad|hone|od)/i.test(navigator.userAgent));

  protected readonly prefersReduced =
    this.isBrowser &&
    window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

  protected readonly showAmbient = !this.prefersReduced;

  // All'interno della classe AppComponent
  constructor() {
    // 1) Intercetta l'inizio della navigazione per lo skip
    this.router.events
      .pipe(filter((e): e is NavigationStart => e instanceof NavigationStart))
      .subscribe((e) => {
        const nav = this.router.getCurrentNavigation();
        const st = (nav?.extras?.state as any) || {};

        // GESTIONE DEL FLAG
        this.skipMotionNext = !!(st.suppressMotion || st.suppressScroll);

        // (RIMUOVENDO QUI IL RESET SCROLL MANUALE)
      });

    // 2) Gestione a NavigationEnd: Pulizia del flag e dello stato.
    let lastPath = '';
    this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe((e) => {
        const path = e.urlAfterRedirects.split('?')[0];
        const pathChanged = lastPath !== path;
        lastPath = path;
        if (!pathChanged) return;

        // TIMEOUT: Resetta il flag *DOPO* un breve timeout.
        setTimeout(() => {
          this.skipMotionNext = false;

          // (RIMUOVENDO QUI IL RESET SCROLL FINALE MANUALE)
        }, 50);
      });
  }

  ngOnInit() {
    if (this.isBrowser) {
      this.viewportService.init();

      const doc = this.document as Document;
      const htmlEl = doc.documentElement as HTMLElement;
      // quando i font/icon sono pronti, abilita classe (evita reflow bruschi)
      if ('fonts' in (doc as any)) {
        (doc as any).fonts.ready.finally(() =>
          htmlEl.classList.add('icons-ready')
        );
      } else {
        htmlEl.classList.add('icons-ready');
      }
    }
  }

  get animParams() {
    const reduce = this.isTouch || this.prefersReduced;
    const isMobile = this.isTouch;

    if (reduce) {
      // Per chi preferisce meno movimento
      return {
        enterDuration: '180ms ease-out',
        leaveDuration: '120ms ease-out',
        enterY: '5px',
        leaveY: '-5px',
      };
    }

    if (isMobile) {
      // Su mobile usiamo un overshoot leggermente meno aggressivo
      return {
        enterDuration: '280ms cubic-bezier(0.2, 0.8, 0.2, 1)', // Meno elastico
        leaveDuration: '180ms ease-out',
        enterY: '8px',
        leaveY: '-8px',
      };
    }

    // Default per desktop, l'effetto "fantastico"
    return {
      enterDuration: '300ms cubic-bezier(0.17, 0.88, 0.32, 1.27)', // Overshoot
      leaveDuration: '200ms ease-out',
      enterY: '10px',
      leaveY: '-10px',
    };
  }

  getRouteAnimationData(outlet: RouterOutlet) {
    // Se i filtri hanno chiesto di saltare l'animazione
    if (this.skipMotionNext) return 'noanim';

    // 1) Se la route ha data.animation, usala (pattern consigliato)
    const dataAnim = outlet?.activatedRouteData?.['animation'];
    if (dataAnim) return dataAnim;

    // 2) Fallback robusto: usa il path corrente (cambia ad ogni navigazione)
    //    Così * <=> * scatta sempre quando cambi pagina
    return this.router.url.split('?')[0] || 'default';
  }
}
