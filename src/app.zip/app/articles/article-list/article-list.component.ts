import {
  Component,
  OnInit,
  HostListener,
  Inject,
  OnDestroy,
  PLATFORM_ID,
  Renderer2,
} from '@angular/core';
import { CommonModule, DOCUMENT, isPlatformBrowser } from '@angular/common';
import {
  ActivatedRoute,
  ParamMap,
  Router,
  RouterModule,
} from '@angular/router';
import { ArticleService, Article } from '../../services/article.service';
import { SidebarComponent } from '../../core/sidebar.component';
import { Meta, Title } from '@angular/platform-browser';
import { DevAdsComponent } from '../../assets/design-system/dev-ads/dev-ads.component';
import { ArticleCardComponent } from '../article-card/article-card.component';
import { env } from '../../config/env';
import { combineLatest, Subscription } from 'rxjs';

@Component({
  selector: 'app-article-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    SidebarComponent,
    DevAdsComponent,
    ArticleCardComponent,
  ],
  templateUrl: './article-list.component.html',
  styleUrls: ['./article-list.component.scss'],
})
export class ArticleListComponent implements OnInit, OnDestroy {
  // LIST DATA
  articles: Article[] = [];
  relatedArticles: Article[] = []; // opzionale (non usato in grid)
  loading = false;
  error = '';
  showAds = false;
  // categoria
  categorySlug: string | null = null;
  categoryName = '';

  // SEO header
  mainTitle = '';
  subTitle = '';

  // PAGINAZIONE
  currentPage = 1;
  pageSize = 19;
  totalItems = 0;
  totalPages = 0;
  readonly paginationRange = 2;

  // ADS
  isMobile = false;
  readonly adEvery = 7;

  // SEO/Schema helpers
  private siteBaseUrl = '';
  private readonly isBrowser: boolean;

  private itemListSchemaScript?: HTMLScriptElement;
  private collectionSchemaScript?: HTMLScriptElement;
  private breadcrumbsSchemaScript?: HTMLScriptElement;

  private routeSub?: Subscription;

  constructor(
    private articleService: ArticleService,
    private route: ActivatedRoute,
    private router: Router,
    private metaService: Meta,
    private titleService: Title,
    private renderer: Renderer2,

    @Inject(DOCUMENT) private doc: Document,
    @Inject(PLATFORM_ID) platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
    if (this.isBrowser) {
      try {
        this.siteBaseUrl = window.location.origin;
      } catch {
        this.siteBaseUrl = '';
      }
    }
    this.preloadFirstCardImage();
  }

  private pageDescriptions: {
    [key: string]: { title: string; description: string };
  } = {
    'all-articles': {
      title: 'All Articles & Guides',
      description:
        'Browse all cocktail articles and guides in one place. Explore recipes, techniques, history, and expert tips to elevate your drink knowledge.',
    },
    'default-category': {
      title: 'Articles & Guides',
      description:
        'Discover articles and guides on cocktails, spirits, and mixology. Learn essential tips, expert insights, and creative ideas for every occasion.',
    },
    'advanced-mixology': {
      title: 'Advanced Mixology',
      description:
        'Dive deep into advanced mixology. Learn cutting-edge techniques, creative flavor pairings, and professional bartender secrets.',
    },
    'bartending-techniques': {
      title: 'Bartending Techniques',
      description:
        'Master bartending techniques with step-by-step guides. From shaking and stirring to layering, learn skills to craft perfect drinks.',
    },
    'best-3-cocktails': {
      title: 'Best 3 Cocktails',
      description:
        'Discover the top 3 cocktails for every taste and occasion. Quick, curated picks with recipes, tips, and variations to try at home.',
    },
    'classic-cocktails': {
      title: 'Classic Cocktails',
      description:
        'Explore timeless classic cocktails like the Martini, Negroni, and Old Fashioned. Learn recipes, origins, and how to perfect each serve.',
    },
    'cocktail-ingredients': {
      title: 'Cocktail Ingredients',
      description:
        'Understand cocktail ingredients from spirits to syrups. Discover how flavors combine, substitutions, and must-have essentials for your bar.',
    },
    'cocktail-innovation': {
      title: 'Cocktail Innovation',
      description:
        'Stay ahead with cocktail innovation. Explore new techniques, creative twists, and modern trends shaping the future of mixology.',
    },
    'drink-history': {
      title: 'Drink History',
      description:
        'Uncover the fascinating history behind cocktails and spirits. Learn the stories, origins, and cultural influences of iconic drinks.',
    },
    'easy-cocktail-recipes': {
      title: 'Easy Cocktail Recipes',
      description:
        'Find easy cocktail recipes for beginners and home bartenders. Simple, quick, and delicious drinks made with a few ingredients.',
    },
    'exotic-sips': {
      title: 'Exotic Sips',
      description:
        'Travel the world through exotic sips. Explore rare ingredients, tropical blends, and adventurous flavors for unique cocktail experiences.',
    },
    'famous-aperitifs': {
      title: 'Famous Aperitifs',
      description:
        'Discover famous aperitifs that open every meal in style. From Spritz to Vermouth, learn recipes and traditions of pre-dinner drinks.',
    },
    'food-pairings': {
      title: 'Food Pairings',
      description:
        'Learn expert cocktail and food pairings. Discover how flavors complement, balance, and elevate dining experiences with the right drink.',
    },
    'glassware-guide': {
      title: 'Glassware Guide',
      description:
        'Find the right glass for every cocktail. Our glassware guide covers styles, functions, and tips for professional-quality presentation.',
    },
    'home-bar-essentials': {
      title: 'Home Bar Essentials',
      description:
        'Build the perfect home bar. Explore must-have tools, ingredients, and tips for creating cocktails like a professional bartender at home.',
    },
    'mocktails-and-zero-proof': {
      title: 'Mocktails & Zero Proof',
      description:
        'Enjoy creative mocktails and zero-proof cocktails. Refreshing, flavorful, and alcohol-free drinks for every occasion.',
    },
    'non-alcoholic-drinks': {
      title: 'Non-Alcoholic Drinks',
      description:
        'Explore non-alcoholic drinks beyond mocktails. From sodas and infusions to creative blends, discover refreshing alcohol-free options.',
    },
    'party-drinks': {
      title: 'Party Drinks',
      description:
        'Make every party unforgettable with crowd-pleasing drinks. Explore big-batch cocktails, festive punches, and celebratory recipes.',
    },
    'seasonal-drinks': {
      title: 'Seasonal Drinks',
      description:
        'Sip with the seasons. Discover cocktails inspired by fresh ingredients and holidays, perfect for spring, summer, autumn, and winter.',
    },
    'spirits-guide': {
      title: 'Spirits Guide',
      description:
        'Navigate the world of spirits with our guide. Learn about vodka, gin, rum, tequila, whiskey, and how to use them in cocktails.',
    },
    'summer-cocktails': {
      title: 'Summer Cocktails',
      description:
        'Stay cool with refreshing summer cocktails. Light, fruity, and vibrant recipes perfect for hot days and outdoor gatherings.',
    },
    'tropical-drinks': {
      title: 'Tropical Drinks',
      description:
        'Escape to paradise with tropical drinks. Discover exotic cocktails with rum, fruit juices, and island-inspired flavors.',
    },
    'winter-warmers': {
      title: 'Winter Warmers',
      description:
        'Cozy up with winter warmers. Explore hot cocktails, spiced blends, and comforting drinks to keep you warm all season.',
    },
  };

  ngOnInit() {
    this.checkScreenWidth();

    this.routeSub = combineLatest([
      this.route.paramMap,
      this.route.queryParams,
    ]).subscribe(([params, qp]: [ParamMap, any]) => {
      this.categorySlug = params.get('slug');
      this.currentPage = parseInt(qp['page'], 10) || 1;
      this.setupHeadersAndLoad();
    });
    this.preloadFirstCardImage();
  }

  ngAfterViewInit(): void {
    if (!this.isBrowser) return;
    const ric: (cb: Function) => any =
      (window as any).requestIdleCallback ||
      ((cb: Function) => setTimeout(cb, 1));

    // Usiamo setTimeout dentro il callback così Angular (Zone.js) trigghera change detection
    ric(() =>
      setTimeout(() => {
        this.showAds = true;
      }, 0)
    );
  }

  ngOnDestroy(): void {
    this.cleanupSeo();
    this.routeSub?.unsubscribe();
  }

  @HostListener('window:resize')
  onResize(): void {
    this.checkScreenWidth();
  }

  private checkScreenWidth(): void {
    if (!this.isBrowser) return;
    try {
      this.isMobile = window.innerWidth <= 600;
    } catch {
      this.isMobile = false;
    }
  }

  private setupHeadersAndLoad() {
    let currentInfo;
    let pageTitleSuffix = ' | Our Cocktail Guides';

    if (this.categorySlug) {
      this.categoryName = this.capitalizeSlug(this.categorySlug);
      currentInfo =
        this.pageDescriptions[this.categorySlug] ||
        this.pageDescriptions['default-category'];

      this.mainTitle = currentInfo.title;
      this.subTitle = `${currentInfo.description}`;
      pageTitleSuffix = ` | ${this.categoryName} Guides`;

      if (
        !this.pageDescriptions[this.categorySlug] &&
        this.categorySlug !== 'default-category'
      ) {
        this.subTitle = `Explore articles and guides on this topic.`;
      }

      this.loadArticlesByCategory(
        this.categorySlug,
        this.currentPage,
        this.pageSize
      );
    } else {
      currentInfo = this.pageDescriptions['all-articles'];
      this.mainTitle = currentInfo.title;
      this.subTitle = currentInfo.description;
      this.loadAllArticles(this.currentPage, this.pageSize);
    }

    this.setPageMeta(
      this.mainTitleWithPage(this.mainTitle),
      this.subTitle,
      pageTitleSuffix
    );
  }

  // LOADERS
  loadAllArticles(page?: number, pageSize?: number) {
    const p = page ?? 1;
    const ps = pageSize ?? this.pageSize;

    this.loading = true;
    this.articleService.getArticles(p, ps).subscribe({
      next: (res) => {
        this.articles = res.data as Article[];
        this.totalItems = res.meta?.pagination?.total ?? 0;
        this.totalPages = res.meta?.pagination?.pageCount ?? 0;
        this.relatedArticles = this.pickRelated(this.articles, 6);
        this.loading = false;
        this.setSeoTagsAndSchemaList();
      },
      error: () => {
        this.error = 'Error loading articles.';
        this.loading = false;
        this.setPageMeta(
          'Error Loading Articles',
          'An error occurred while loading articles. Please try again later.',
          ' | Cocktail Guides'
        );
        this.relatedArticles = [];
        this.setSeoTagsAndSchemaList();
      },
    });
  }

  loadArticlesByCategory(slug: string, page?: number, pageSize?: number) {
    const p = page ?? 1;
    const ps = pageSize ?? this.pageSize;

    this.loading = true;
    this.articleService.getArticlesByCategorySlug(slug, p, ps).subscribe({
      next: (res) => {
        this.articles = res.data as Article[];
        this.totalItems = res.meta?.pagination?.total ?? 0;
        this.totalPages = res.meta?.pagination?.pageCount ?? 0;
        this.relatedArticles = this.pickRelated(this.articles, 6);
        this.loading = false;
        this.setSeoTagsAndSchemaList();
      },
      error: () => {
        this.error = 'Error loading articles for this category.';
        this.loading = false;
        const categoryDisplayName = this.capitalizeSlug(slug);
        this.setPageMeta(
          `Error Loading ${categoryDisplayName} Articles`,
          `An error occurred while loading articles for ${categoryDisplayName}. Please try again later.`,
          ` | ${categoryDisplayName} Guides`
        );
        this.relatedArticles = [];
        this.setSeoTagsAndSchemaList();
      },
    });
  }

  // Sceglie i correlati dalla lista corrente (semplice: primi N diversi)
  private pickRelated(list: Article[], max = 6): Article[] {
    if (!Array.isArray(list) || list.length === 0) return [];
    return list.slice(0, Math.min(max, list.length));
  }

  // PAGINATORE
  goToPage(page: number) {
    if (page < 1 || page > this.totalPages || page === this.currentPage) return;

    this.router
      .navigate([], {
        relativeTo: this.route,
        queryParams: { page },
        queryParamsHandling: 'merge',
      })
      .then(() => this.scrollToTop());
  }

  private scrollToTop(): void {
    if (!this.isBrowser) return;
    requestAnimationFrame(() => {
      try {
        window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
      } catch {
        window.scrollTo(0, 0);
      }
    });
  }

  buildUrlWithParams(patch: Record<string, string | number | null>): string {
    const path =
      this.router.url.split('?')[0] ||
      (this.categorySlug
        ? `/articles/category/${this.categorySlug}`
        : '/articles');

    const current = { ...this.route.snapshot.queryParams } as Record<
      string,
      any
    >;
    for (const k of Object.keys(patch)) {
      const v = patch[k];
      if (v === null) delete current[k];
      else current[k] = String(v);
    }
    const qs = new URLSearchParams(current as any).toString();
    return qs ? `${path}?${qs}` : path;
  }

  getVisiblePages(): number[] {
    const pages: number[] = [];
    const startPage = Math.max(2, this.currentPage - this.paginationRange);
    const endPage = Math.min(
      this.totalPages - 1,
      this.currentPage + this.paginationRange
    );
    for (let i = startPage; i <= endPage; i++) pages.push(i);
    return pages;
  }
  showFirstEllipsis(): boolean {
    return this.totalPages > 1 && this.currentPage > this.paginationRange + 1;
  }
  showLastEllipsis(): boolean {
    return (
      this.totalPages > 1 &&
      this.currentPage < this.totalPages - this.paginationRange
    );
  }

  // Utils
  getImageUrl(image?: { url?: string; formats?: any }): string {
    if (!image) return 'assets/images/placeholder_article.png';
    const url = image.formats?.thumbnail?.url ?? image.url ?? '';
    if (!url) return 'assets/images/placeholder_article.png';
    return url.startsWith('http') ? url : `${env.apiUrl}${url}`;
  }

  private getArticleImageUrl(a?: Article): string {
    if (!a) return this.getFullSiteUrl('/assets/og-default.png');
    if (a.imageUrl) {
      return a.imageUrl.startsWith('http')
        ? a.imageUrl
        : env.apiUrl + a.imageUrl;
    }
    return this.getImageUrl(a.image);
  }

  private capitalizeSlug(slug: string): string {
    return slug
      .split('-')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
  }

  private mainTitleWithPage(base: string): string {
    return this.totalPages > 1
      ? `${base} (Page ${this.currentPage}${
          this.totalPages ? ' of ' + this.totalPages : ''
        })`
      : base;
  }

  private setPageMeta(title: string, description: string, suffix: string) {
    this.titleService.setTitle(`${title}${suffix}`);
    this.metaService.updateTag({ name: 'description', content: description });
  }

  trackByArticleId(_i: number, a: any) {
    return a.id ?? a.documentId ?? a.slug;
  }

  // Helpers URL assolute
  private getFullSiteUrl(pathOrUrl: string): string {
    if (!this.siteBaseUrl) return pathOrUrl;
    return pathOrUrl.startsWith('http')
      ? pathOrUrl
      : `${this.siteBaseUrl}${pathOrUrl}`;
  }

  private getCurrentPath(): string {
    return (
      this.router.url.split('?')[0] ||
      (this.categorySlug
        ? `/articles/category/${this.categorySlug}`
        : '/articles')
    );
  }

  // SEO dyn
  private buildDynamicTitle(): string {
    const base = this.categorySlug
      ? `${this.mainTitle || this.categoryName}`
      : `${this.mainTitle || 'Articles'}`;

    const pageSuffix =
      this.totalPages > 1
        ? ` (Page ${this.currentPage}${
            this.totalPages ? ' of ' + this.totalPages : ''
          })`
        : '';

    const brand = this.categorySlug
      ? ` | ${this.categoryName} Guides`
      : ' | Our Cocktail Guides';
    return `${base}${pageSuffix}${brand}`;
  }

  private truncate(text: string, maxLen: number): string {
    if (!text) return '';
    return text.length <= maxLen
      ? text
      : text.slice(0, maxLen - 1).trimEnd() + '…';
  }

  private buildDynamicDescription(): string {
    const parts: string[] = [];

    if (this.categorySlug) {
      parts.push(
        `Explore ${this.categoryName} articles and guides${
          this.totalItems ? ` (${this.totalItems} in archive)` : ''
        }`
      );
    } else {
      parts.push(
        this.totalItems
          ? `Browse ${this.totalItems} cocktail articles & guides`
          : 'Browse cocktail articles & guides'
      );
    }

    parts.push(
      'Discover recipes, techniques, history, innovation and more for enthusiasts and professionals'
    );

    return this.truncate(parts.join('. ') + '.', 158);
  }

  // Canonical / Prev / Next
  private setCanonicalLink(absUrl: string): void {
    const head = this.doc?.head;
    if (!head) return;

    let linkEl = head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!linkEl) {
      linkEl = this.renderer.createElement('link');
      this.renderer.setAttribute(linkEl, 'rel', 'canonical');
      this.renderer.appendChild(head, linkEl);
    }
    this.renderer.setAttribute(linkEl, 'href', absUrl);
  }

  private setPrevNextLinks(
    prevAbs: string | null,
    nextAbs: string | null
  ): void {
    const head = this.doc?.head;
    if (!head) return;

    head
      .querySelectorAll('link[rel="prev"], link[rel="next"]')
      .forEach((el) => {
        this.renderer.removeChild(head, el);
      });

    if (prevAbs) {
      const prev = this.renderer.createElement('link');
      this.renderer.setAttribute(prev, 'rel', 'prev');
      this.renderer.setAttribute(prev, 'href', prevAbs);
      this.renderer.appendChild(head, prev);
    }
    if (nextAbs) {
      const next = this.renderer.createElement('link');
      this.renderer.setAttribute(next, 'rel', 'next');
      this.renderer.setAttribute(next, 'href', nextAbs);
      this.renderer.appendChild(head, next);
    }
  }

  // JSON-LD
  private cleanupJsonLdScript(ref?: HTMLScriptElement) {
    const head = this.doc?.head;
    if (!head || !ref) return;
    if (head.contains(ref)) {
      this.renderer.removeChild(head, ref);
    }
  }

  private addJsonLdItemList(): void {
    const head = this.doc?.head;
    if (!head) return;

    this.cleanupJsonLdScript(this.itemListSchemaScript);

    const script = this.renderer.createElement('script');
    this.renderer.setAttribute(script, 'type', 'application/ld+json');
    this.renderer.setAttribute(script, 'id', 'article-itemlist-schema');

    const pageAbsUrl = this.getFullSiteUrl(this.router.url);
    const itemListId = pageAbsUrl + '#itemlist';
    const collectionId = pageAbsUrl + '#collection'; // ✅

    const startIndex = this.pageStart || 1;

    const itemList = {
      '@context': 'https://schema.org',
      '@type': 'ItemList',
      '@id': itemListId,
      name: this.mainTitle || 'Articles & Guides',
      inLanguage: 'en',
      itemListOrder: 'https://schema.org/ItemListOrderAscending',
      numberOfItems: this.totalItems,
      startIndex,
      url: pageAbsUrl,
      isPartOf: { '@id': collectionId }, // ✅ collega alla CollectionPage
      itemListElement: this.articles.map((a, i) => ({
        '@type': 'ListItem',
        position: startIndex + i,
        item: {
          '@type': 'Article',
          '@id': this.getFullSiteUrl(`/articles/${a.slug}`),
          url: this.getFullSiteUrl(`/articles/${a.slug}`),
          name: a.title,
          image: this.getArticleImageUrl(a),
        },
      })),
    };

    this.renderer.appendChild(
      script,
      this.renderer.createText(JSON.stringify(itemList))
    );
    this.renderer.appendChild(head, script);
    this.itemListSchemaScript = script as HTMLScriptElement;
  }

  private addJsonLdCollectionPageAndBreadcrumbs(
    pageTitle: string,
    pageDescription: string
  ): void {
    const head = this.doc?.head;
    if (!head) return;

    // CollectionPage
    this.cleanupJsonLdScript(this.collectionSchemaScript);
    const coll = this.renderer.createElement('script');
    this.renderer.setAttribute(coll, 'type', 'application/ld+json');
    this.renderer.setAttribute(coll, 'id', 'collectionpage-schema');

    const pageAbsUrl = this.getFullSiteUrl(this.router.url);
    const itemListId = pageAbsUrl + '#itemlist';
    const collectionId = pageAbsUrl + '#collection';

    const collectionPage = {
      '@context': 'https://schema.org',
      '@type': 'CollectionPage',
      '@id': collectionId, // ✅
      name: pageTitle.replace(/ \|.*$/, ''),
      description: pageDescription,
      url: pageAbsUrl,
      mainEntity: { '@id': itemListId },
      inLanguage: 'en', // ✅
    };
    this.renderer.appendChild(
      coll,
      this.renderer.createText(JSON.stringify(collectionPage))
    );
    this.renderer.appendChild(head, coll);
    this.collectionSchemaScript = coll as HTMLScriptElement;

    // BreadcrumbList
    this.cleanupJsonLdScript(this.breadcrumbsSchemaScript);
    const bc = this.renderer.createElement('script');
    this.renderer.setAttribute(bc, 'type', 'application/ld+json');
    this.renderer.setAttribute(bc, 'id', 'breadcrumbs-schema');

    const crumbs: Array<{ name: string; url: string }> = [
      { name: 'Home', url: this.getFullSiteUrl('/') },
      { name: 'Articles', url: this.getFullSiteUrl('/articles') },
    ];
    if (this.categorySlug) {
      crumbs.push({
        name: this.categoryName,
        url: this.getFullSiteUrl(`/articles/category/${this.categorySlug}`),
      });
    }

    const breadcrumbList = {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: crumbs.map((c, i) => ({
        '@type': 'ListItem',
        position: i + 1,
        name: c.name,
        item: c.url,
      })),
    };
    this.renderer.appendChild(
      bc,
      this.renderer.createText(JSON.stringify(breadcrumbList))
    );
    this.renderer.appendChild(head, bc);
    this.breadcrumbsSchemaScript = bc as HTMLScriptElement;
  }

  // SEO: LIST
  private setSeoTagsAndSchemaList(): void {
    const title = this.buildDynamicTitle();
    const description = this.buildDynamicDescription();

    this.titleService.setTitle(title);
    this.metaService.updateTag({ name: 'description', content: description });

    // ✅ Canonical senza ?page=1
    const canonicalPath =
      this.currentPage === 1
        ? this.buildUrlWithParams({ page: null })
        : this.buildUrlWithParams({ page: this.currentPage });
    const canonicalAbs = this.getFullSiteUrl(canonicalPath);
    this.setCanonicalLink(canonicalAbs);

    const prevUrl =
      this.totalPages > 1 && this.currentPage > 1
        ? this.getFullSiteUrl(
            this.buildUrlWithParams({ page: this.currentPage - 1 })
          )
        : null;
    const nextUrl =
      this.totalPages > 1 && this.currentPage < this.totalPages
        ? this.getFullSiteUrl(
            this.buildUrlWithParams({ page: this.currentPage + 1 })
          )
        : null;
    this.setPrevNextLinks(prevUrl, nextUrl);

    const ogImage =
      this.articles.length > 0
        ? this.getArticleImageUrl(this.articles[0])
        : this.getFullSiteUrl('/assets/og-default.png');

    this.metaService.updateTag({ property: 'og:title', content: title });
    this.metaService.updateTag({
      property: 'og:description',
      content: description,
    });
    this.metaService.updateTag({ property: 'og:url', content: canonicalAbs });
    this.metaService.updateTag({ property: 'og:type', content: 'website' });
    this.metaService.updateTag({ property: 'og:image', content: ogImage });
    this.metaService.updateTag({
      property: 'og:site_name',
      content: 'Fizzando',
    });

    this.metaService.updateTag({
      name: 'twitter:card',
      content: 'summary_large_image',
    });
    this.metaService.updateTag({ name: 'twitter:title', content: title });
    this.metaService.updateTag({
      name: 'twitter:description',
      content: description,
    });
    this.metaService.updateTag({ name: 'twitter:image', content: ogImage });

    this.addJsonLdItemList();
    this.addJsonLdCollectionPageAndBreadcrumbs(title, description);
  }

  private cleanupSeo(): void {
    this.metaService.removeTag("property='og:title'");
    this.metaService.removeTag("property='og:description'");
    this.metaService.removeTag("property='og:image'");
    this.metaService.removeTag("property='og:url'");
    this.metaService.removeTag("property='og:type'");
    this.metaService.removeTag("property='og:site_name'");
    this.metaService.removeTag("name='twitter:card'");
    this.metaService.removeTag("name='twitter:title'");
    this.metaService.removeTag("name='twitter:description'");
    this.metaService.removeTag("name='twitter:image'");

    const head = this.doc?.head;
    if (head) {
      head
        .querySelectorAll('link[rel="prev"], link[rel="next"]')
        .forEach((el) => {
          this.renderer.removeChild(head, el);
        });
    }

    this.cleanupJsonLdScript(this.itemListSchemaScript);
    this.cleanupJsonLdScript(this.collectionSchemaScript);
    this.cleanupJsonLdScript(this.breadcrumbsSchemaScript);
  }

  // Range visibile (1-based)
  get pageStart(): number {
    return this.totalItems > 0 ? (this.currentPage - 1) * this.pageSize + 1 : 0;
  }
  get pageEnd(): number {
    return this.totalItems > 0
      ? Math.min(this.currentPage * this.pageSize, this.totalItems)
      : 0;
  }

  // in ArticleListComponent (in fondo o dove preferisci)
  private addPreconnectToAssets(): void {
    if (!this.isBrowser) return;
    try {
      const u = new URL(env.apiUrl);
      const href = `${u.protocol}//${u.host}`;
      const head = this.doc.head;
      if (
        head &&
        !head.querySelector(`link[rel="preconnect"][href="${href}"]`)
      ) {
        const l = this.renderer.createElement('link');
        this.renderer.setAttribute(l, 'rel', 'preconnect');
        this.renderer.setAttribute(l, 'href', href);
        this.renderer.setAttribute(l, 'crossorigin', '');
        this.renderer.appendChild(head, l);
      }
    } catch {}
  }

  private preloadFirstCardImage(): void {
    if (!this.isBrowser || !this.articles?.length) return;
    const a = this.articles[0] as any;
    const f = a?.image?.formats || {};
    // prendo la più adatta per mobile/prime viewport
    const src = (f.thumbnail?.url ||
      f.small?.url ||
      f.medium?.url ||
      a?.image?.url) as string | undefined;
    if (!src) return;

    const srcAbs = src.startsWith('http') ? src : `${env.apiUrl}${src}`;

    // costruisco imagesrcset (se disponibile)
    const set: string[] = [];
    if (f.thumbnail?.url && f.thumbnail?.width)
      set.push(
        `${
          f.thumbnail.url.startsWith('http')
            ? f.thumbnail.url
            : env.apiUrl + f.thumbnail.url
        } ${f.thumbnail.width}w`
      );
    if (f.small?.url && f.small?.width)
      set.push(
        `${
          f.small.url.startsWith('http')
            ? f.small.url
            : env.apiUrl + f.small.url
        } ${f.small.width}w`
      );
    if (f.medium?.url && f.medium?.width)
      set.push(
        `${
          f.medium.url.startsWith('http')
            ? f.medium.url
            : env.apiUrl + f.medium.url
        } ${f.medium.width}w`
      );

    const link = this.renderer.createElement('link');
    this.renderer.setAttribute(link, 'rel', 'preload');
    this.renderer.setAttribute(link, 'as', 'image');
    this.renderer.setAttribute(link, 'href', srcAbs);
    this.renderer.setAttribute(
      link,
      'imagesizes',
      '(max-width: 600px) 100vw, (max-width: 1024px) 50vw, 239px'
    );
    if (set.length)
      this.renderer.setAttribute(link, 'imagesrcset', set.join(', '));
    this.renderer.appendChild(this.doc.head, link);
  }
}
