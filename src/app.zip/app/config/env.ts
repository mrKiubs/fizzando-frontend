export const env = {
  production: false,
  apiBaseUrl: 'http://127.0.0.1:1337',
  apiUrl: 'http://127.0.0.1:1337',
};
